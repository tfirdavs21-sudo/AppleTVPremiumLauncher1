package com.appletv.premium;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.HorizontalScrollView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout root, appRow;
    private final List<View> tiles = new ArrayList<>();
    private int focused = 0;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildScreen();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(42), dp(22), dp(42), dp(20));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(16,27,51), Color.rgb(7,10,19), Color.rgb(25,18,42)}));
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("  TV", 27, Color.WHITE, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));
        String date = new SimpleDateFormat("EEE, d MMM  •  HH:mm", Locale.getDefault()).format(new Date());
        TextView clock = text(date, 16, 0xFFD8DEEA, false);
        clock.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        top.addView(clock);
        root.addView(top);

        TextView hero = text("Добро пожаловать", 31, Color.WHITE, true);
        hero.setPadding(dp(26), 0, 0, 0);
        hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0xFF314A78, 0xFF202A49, 0xFF34254D}));
        hero.getBackground().setAlpha(235);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, dp(150));
        hp.setMargins(0, dp(22), 0, dp(24));
        hero.setBackground(roundGradient());
        root.addView(hero, hp);

        TextView heading = text("ВАШИ ПРИЛОЖЕНИЯ", 14, 0xFFB8C4DA, true);
        heading.setPadding(dp(4), 0, 0, dp(12));
        root.addView(heading);

        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        appRow = new LinearLayout(this);
        appRow.setOrientation(LinearLayout.HORIZONTAL);
        scroll.addView(appRow);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, dp(138)));

        loadApps();

        TextView hint = text("Используйте стрелки пульта для выбора  •  OK — открыть приложение",
            12, 0xFF8794AA, false);
        hint.setPadding(dp(4), dp(20), 0, 0);
        root.addView(hint);
        if (!tiles.isEmpty()) {
            focused = 0;
            tiles.get(0).requestFocus();
        }
    }

    private GradientDrawable roundGradient() {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0xFF385B91, 0xFF242F53, 0xFF46345F});
        d.setCornerRadius(dp(22));
        return d;
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        if (apps == null || apps.isEmpty()) {
            query.removeCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
            query.addCategory(Intent.CATEGORY_LAUNCHER);
            apps = pm.queryIntentActivities(query, 0);
        }
        for (ResolveInfo info : apps) {
            final String pkg = info.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setFocusable(true);
            tile.setFocusableInTouchMode(true);
            tile.setBackground(bg(0xFF202A40, 17));
            tile.setPadding(dp(10), dp(10), dp(10), dp(8));
            TextView icon = text("▶", 31, Color.WHITE, true);
            icon.setGravity(Gravity.CENTER);
            tile.addView(icon, new LinearLayout.LayoutParams(-1, dp(62)));
            TextView name = text(info.loadLabel(pm).toString(), 13, Color.WHITE, true);
            name.setGravity(Gravity.CENTER);
            name.setMaxLines(2);
            tile.addView(name, new LinearLayout.LayoutParams(dp(112), dp(38)));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(132), dp(118));
            p.setMargins(0, 0, dp(14), 0);
            appRow.addView(tile, p);
            tiles.add(tile);
            tile.setOnFocusChangeListener((v, has) -> {
                v.setBackground(bg(has ? 0xFF5479B8 : 0xFF202A40, has ? 19 : 17));
                v.setScaleX(has ? 1.08f : 1f);
                v.setScaleY(has ? 1.08f : 1f);
            });
            tile.setOnClickListener(v -> {
                Intent launch = pm.getLaunchIntentForPackage(pkg);
                if (launch != null) startActivity(launch);
            });
        }
        if (tiles.isEmpty()) {
            TextView empty = text("Приложения не найдены", 16, Color.WHITE, false);
            appRow.addView(empty);
        }
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) return true;
        return super.onKeyDown(keyCode, event);
    }
}
